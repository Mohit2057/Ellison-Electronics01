package Service;

public interface TransService {

	public String getUserId(String transId);
}
